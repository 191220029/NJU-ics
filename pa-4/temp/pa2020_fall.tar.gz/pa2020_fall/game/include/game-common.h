#ifndef __GAME_H__
#define __GAME_H__

void timer_event(void);
void keyboard_event(int scan_code);

void main_loop(void);

#endif
