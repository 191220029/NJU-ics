#include "hal.h"
#include "device/video.h"
#include "device/palette.h"

#include <string.h>
#include <stdlib.h>

#define PIXEL_OFFSET(dst, x, y) (((dst)->pitch) * y + x)
#define PIXEL_PTR(dst, x, y) ({SDL_Surface *_dst = dst; assert(_dst->pitch == _dst->w); \
    (((char *) (_dst->pixels)) + PIXEL_OFFSET(_dst, x, y)); })

#define max(a, b) (a > b)?a:b
#define min(a, b) (a < b)?a:b

int get_fps();

void get_SurfaceRect(SDL_Surface *surface, SDL_Rect *rect);
void get_ClipRect(SDL_Surface *surface, SDL_Rect *rect);
bool intersectRect(SDL_Rect *A, SDL_Rect *B, SDL_Rect *res);


void SDL_BlitSurface(SDL_Surface *src, SDL_Rect *srcrect,
					 SDL_Surface *dst, SDL_Rect *dstrect)
{
	assert(dst && src);

	//int sx = (srcrect == NULL ? 0 : srcrect->x);
	//int sy = (srcrect == NULL ? 0 : srcrect->y);
	//int dx = (dstrect == NULL ? 0 : dstrect->x);
	//int dy = (dstrect == NULL ? 0 : dstrect->y);
	//int w = (srcrect == NULL ? src->w : srcrect->w);
	//int h = (srcrect == NULL ? src->h : srcrect->h);
	//if(dst->w - dx < w) { w = dst->w - dx; }
	//if(dst->h - dy < h) { h = dst->h - dy; }
	//if(dstrect != NULL) {
	//	dstrect->w = w;
	//	dstrect->h = h;
	//}
    
    int sx = (srcrect == NULL ? 0 : srcrect->x);
	int sy = (srcrect == NULL ? 0 : srcrect->y);
	int dx = (dstrect == NULL ? 0 : dstrect->x);
	int dy = (dstrect == NULL ? 0 : dstrect->y);
	int w = (srcrect == NULL ? src->w : srcrect->w);
	int h = (srcrect == NULL ? src->h : srcrect->h);
	if(dst->w - dx < w) { w = dst->w - dx; }
	if(dst->h - dy < h) { h = dst->h - dy; }
	if(dstrect != NULL) {
		dstrect->w = w;
		dstrect->h = h;
	}
    
	/* TODO: copy pixels from position (`sx', `sy') with size
	 * `w' X `h' of `src' surface to position (`dx', `dy') of
	 * `dst' surface.
	 */
    //*dst->pixels = *src->pixels;
    
    int dst_line, src_line;
    for(dst_line = dy, src_line = sy; h--; dst_line++, src_line++) {
        memcpy(PIXEL_PTR(dst, dx, dst_line), PIXEL_PTR(src, sx, src_line), w);
        assert(dst_line < dst->h);
        assert(src_line < src->h);
        assert(dx + w <= dst->w);
        assert(sx + w <= src->w);
    }

    return;
	//assert(0);
}

void SDL_FillRect(SDL_Surface *dst, SDL_Rect *dstrect, uint32_t color)
{
	assert(dst);
	assert(color <= 0xff);

	/* TODO: Fill the rectangle area described by `dstrect'
	 * in surface `dst' with color `color'. If dstrect is
	 * NULL, fill the whole surface.
	 */
    //
    bool rect_flag;
    
    SDL_Rect dst_surfuce_rect;
    get_ClipRect(dst, &dst_surfuce_rect);
    
    if(dstrect){
        rect_flag = intersectRect(dstrect, &dst_surfuce_rect, &dst_surfuce_rect);
        if(!rect_flag)return;
    }
    
    int height = dst_surfuce_rect.h;
    int width = dst_surfuce_rect.w;
    
    int dst_line;
    for(dst_line = dst_surfuce_rect.y; height--; dst_line++) {
        memset(PIXEL_PTR(dst, dst_surfuce_rect.x, dst_line), color, width);
        assert(dst_line < dst->h);
        assert(dst_surfuce_rect.x + width <= dst->w);
    }
    return;
	//assert(0);
}

void SDL_SetPalette(SDL_Surface *s, int flags, SDL_Color *colors,
					int firstcolor, int ncolors)
{
	assert(s);
	assert(s->format);
	assert(s->format->palette);
	assert(firstcolor == 0);

	if (s->format->palette->colors == NULL || s->format->palette->ncolors != ncolors)
	{
		if (s->format->palette->ncolors != ncolors && s->format->palette->colors != NULL)
		{
			/* If the size of the new palette is different 
			 * from the old one, free the old one.
			 */
			free(s->format->palette->colors);
		}

		/* Get new memory space to store the new palette. */
		s->format->palette->colors = malloc(sizeof(SDL_Color) * ncolors);
		assert(s->format->palette->colors);
	}

	/* Set the new palette. */
	s->format->palette->ncolors = ncolors;
	memcpy(s->format->palette->colors, colors, sizeof(SDL_Color) * ncolors);
    

	if (s->flags & SDL_HWSURFACE)
	{
		/* TODO: Set the VGA palette by calling write_palette(). */
        write_palette(colors, ncolors);
        //write_palette(s->format->palette->colors, s->format->palette->ncolors);
		//assert(0);
	}
}

void get_SurfaceRect(SDL_Surface *surface, SDL_Rect *rect){
    rect->x = rect->y = 0;
    rect->w = surface->w;
    rect->h = surface->h;
}

void get_ClipRect(SDL_Surface *surface, SDL_Rect *rect) {
    SDL_Rect *clip_rect = &surface->clip_rect;
    if(clip_rect->x == 0 && clip_rect->y == 0 && clip_rect->h == 0 && clip_rect->w == 0)
        get_SurfaceRect(surface, rect);
    else *rect = *clip_rect;
    assert(rect->x == 0 && rect->y == 0);
    assert(rect->x + rect->w <= surface->w);
    assert(rect->y + rect->h <= surface->h);
}

bool intersectRect(SDL_Rect *A, SDL_Rect *B, SDL_Rect *res){
    int left = max(A->x, B->x);
    int right = min(A->x + A->w, B->x + B->w);
    int top = max(A->y, B->y);
    int bottom = min(A->y + A->h, B->y + B->h);
    if(right > left && bottom > top){
        res->x = left, res->y = top;
        res->w = right - left; res->h = bottom - top;
        return true;
    }
    return false;
}

/* ======== The following functions are already implemented. ======== */

void SDL_UpdateRect(SDL_Surface *screen, int x, int y, int w, int h)
{
	assert(screen);
	assert(screen->pitch == 320);

	// this should always be true in NEMU-PAL
	assert(screen->flags & SDL_HWSURFACE);

	if (x == 0 && y == 0)
	{
		/* Draw FPS */
		vmem = VMEM_ADDR;
		char buf[80];
		sprintf(buf, "%dFPS", get_fps());
		draw_string(buf, 0, 0, 10);
	}
}

void SDL_SoftStretch(SDL_Surface *src, SDL_Rect *srcrect,
					 SDL_Surface *dst, SDL_Rect *dstrect)
{
	assert(src && dst);
	int x = (srcrect == NULL ? 0 : srcrect->x);
	int y = (srcrect == NULL ? 0 : srcrect->y);
	int w = (srcrect == NULL ? src->w : srcrect->w);
	int h = (srcrect == NULL ? src->h : srcrect->h);

	assert(dstrect);
	if (w == dstrect->w && h == dstrect->h)
	{
		/* The source rectangle and the destination rectangle
		 * are of the same size. If that is the case, there
		 * is no need to stretch, just copy. */
		SDL_Rect rect;
		rect.x = x;
		rect.y = y;
		rect.w = w;
		rect.h = h;
		SDL_BlitSurface(src, &rect, dst, dstrect);
	}
	else
	{
		/* No other case occurs in NEMU-PAL. */
		assert(0);
	}
}

SDL_Surface *SDL_CreateRGBSurface(uint32_t flags, int width, int height, int depth,
								  uint32_t Rmask, uint32_t Gmask, uint32_t Bmask, uint32_t Amask)
{
	SDL_Surface *s = malloc(sizeof(SDL_Surface));
	assert(s);
	s->format = malloc(sizeof(SDL_PixelFormat));
	assert(s);
	s->format->palette = malloc(sizeof(SDL_Palette));
	assert(s->format->palette);
	s->format->palette->colors = NULL;

	s->format->BitsPerPixel = depth;

	s->flags = flags;
	s->w = width;
	s->h = height;
	s->pitch = (width * depth) >> 3;
	s->pixels = (flags & SDL_HWSURFACE ? (void *)VMEM_ADDR : malloc(s->pitch * height));
	assert(s->pixels);

	return s;
}

SDL_Surface *SDL_SetVideoMode(int width, int height, int bpp, uint32_t flags)
{
	return SDL_CreateRGBSurface(flags, width, height, bpp,
								0x000000ff, 0x0000ff00, 0x00ff0000, 0xff000000);
}

void SDL_FreeSurface(SDL_Surface *s)
{
	if (s != NULL)
	{
		if (s->format != NULL)
		{
			if (s->format->palette != NULL)
			{
				if (s->format->palette->colors != NULL)
				{
					free(s->format->palette->colors);
				}
				free(s->format->palette);
			}

			free(s->format);
		}

		if (s->pixels != NULL && s->pixels != VMEM_ADDR)
		{
			free(s->pixels);
		}

		free(s);
	}
}
