#ifndef __INSTR_FLAGS_H__
#define __INSTR_FLAGS_H__

make_instr_func(cld);
make_instr_func(clc);
make_instr_func(sahf);
make_instr_func(bt_r2rm_v);

#endif
