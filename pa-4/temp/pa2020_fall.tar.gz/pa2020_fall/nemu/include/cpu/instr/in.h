#ifndef __INSTR_IN_H__
#define __INSTR_IN_H__
/*
Put the declarations of `in' instructions here.
*/

make_instr_func(in_b);

make_instr_func(in_v);

#endif
