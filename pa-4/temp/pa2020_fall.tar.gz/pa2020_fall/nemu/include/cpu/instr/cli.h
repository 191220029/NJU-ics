#ifndef __INSTR_CLI_H__
#define __INSTR_CLI_H__
/*
Put the declarations of `cli' instructions here.
*/

make_instr_func(cli);

#endif
