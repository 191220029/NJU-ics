#ifndef __INSTR_JMP_H__
#define __INSTR_JMP_H__

make_instr_func(jmp_near);
make_instr_func(jmp_short_);
make_instr_func(jmp_rmv_near);
make_instr_func(jmp_via_seg);

#endif
