#ifndef __INSTR_LEA_H__
#define __INSTR_LEA_H__
/*
Put the declarations of `lea' instructions here.
*/
make_instr_func(lea_rm2r_v);


#endif
