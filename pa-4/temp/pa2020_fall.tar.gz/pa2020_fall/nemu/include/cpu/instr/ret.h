#ifndef __INSTR_RET_H__
#define __INSTR_RET_H__
/*
Put the declarations of `ret' instructions here.
*/

make_instr_func(ret_near);
make_instr_func(ret_i_wnear);
//make_instr_func(ret_far);

#endif
