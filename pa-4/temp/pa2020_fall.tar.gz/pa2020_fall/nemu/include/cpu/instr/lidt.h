#ifndef __INSTR_LIDT_H__
#define __INSTR_LIDT_H__
/*
Put the declarations of `lidt' instructions here.
*/

make_instr_func(lidt);

#endif
