#ifndef __INSTR_STI_H__
#define __INSTR_STI_H__
/*
Put the declarations of `sti' instructions here.
*/

make_instr_func(sti);

#endif
