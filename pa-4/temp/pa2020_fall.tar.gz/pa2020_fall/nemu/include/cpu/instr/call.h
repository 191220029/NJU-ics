#ifndef __INSTR_CALL_H__
#define __INSTR_CALL_H__
/*
Put the declarations of `call' instructions here.
*/

make_instr_func(call_re116_w);
make_instr_func(call_rm_v);


#endif
