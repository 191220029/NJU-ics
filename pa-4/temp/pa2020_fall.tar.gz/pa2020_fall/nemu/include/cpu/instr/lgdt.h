#ifndef __INSTR_LGDT_H__
#define __INSTR_LGDT_H__
/*
Put the declarations of `lgdt' instructions here.
*/
make_instr_func(lgdt);

#endif
