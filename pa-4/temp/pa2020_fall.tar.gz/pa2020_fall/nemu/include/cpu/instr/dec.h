#ifndef __INSTR_DEC_H__
#define __INSTR_DEC_H__
/*
Put the declarations of `dec' instructions here.
*/

make_instr_func(dec_r_v);
make_instr_func(dec_rm_v);

#endif
