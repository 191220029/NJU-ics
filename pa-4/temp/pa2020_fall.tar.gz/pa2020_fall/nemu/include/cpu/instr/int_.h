#ifndef __INSTR_INT_H__
#define __INSTR_INT_H__
/*
Put the declarations of `int' instructions here.

Special note for `int': please use the instruction name `int_' instead of `int'.
*/

make_instr_func(int_ib);

#endif
