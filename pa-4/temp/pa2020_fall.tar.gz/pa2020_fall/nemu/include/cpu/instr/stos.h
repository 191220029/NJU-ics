#ifndef __INSTR_STOS_H__
#define __INSTR_STOS_H__

make_instr_func(stos_b);
make_instr_func(stos_v);

#endif
