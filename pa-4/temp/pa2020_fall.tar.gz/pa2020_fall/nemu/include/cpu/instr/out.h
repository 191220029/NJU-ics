#ifndef __INSTR_OUT_H__
#define __INSTR_OUT_H__
/*
Put the declarations of `out' instructions here.
*/

make_instr_func(out_b);

make_instr_func(out_v);

#endif
