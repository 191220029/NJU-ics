#ifndef __INSTR_LEAVE_H__
#define __INSTR_LEAVE_H__
/*
Put the declarations of `leave' instructions here.
*/

make_instr_func(leave_32);


#endif
