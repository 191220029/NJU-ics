#ifndef __INSTR_IRET_H__
#define __INSTR_IRET_H__
/*
Put the declarations of `iret' instructions here.
*/

make_instr_func(iret);

#endif
