#ifndef __INSTR_NEG_H__
#define __INSTR_NEG_H__
/*
Put the declarations of `neg' instructions here.
*/

make_instr_func(neg_rm_v);

#endif
