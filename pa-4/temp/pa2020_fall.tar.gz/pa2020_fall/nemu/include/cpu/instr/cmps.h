#ifndef __INSTR_CMPS_H__
#define __INSTR_CMPS_H__

make_instr_func(cmps_v);
make_instr_func(cmps_b);

#endif
