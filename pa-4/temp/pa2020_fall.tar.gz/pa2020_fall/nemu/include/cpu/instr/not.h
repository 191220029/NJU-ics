#ifndef __INSTR_NOT_H__
#define __INSTR_NOT_H__
/*
Put the declarations of `not' instructions here.
*/

make_instr_func(not_rm_v);

#endif
