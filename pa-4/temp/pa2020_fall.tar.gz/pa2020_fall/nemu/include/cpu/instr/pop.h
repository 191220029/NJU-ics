#ifndef __INSTR_POP_H__
#define __INSTR_POP_H__
/*
Put the declarations of `pop' instructions here.
*/

make_instr_func(pop_r_v);


make_instr_func(pop_rebx_v);
make_instr_func(pop_rebp_v);

make_instr_func(popa);

#endif
