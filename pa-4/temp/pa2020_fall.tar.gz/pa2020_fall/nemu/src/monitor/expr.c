#include "nemu.h"
#include "cpu/reg.h"
#include "memory/memory.h"

//added include file:
//#include "../src/monitor/elf.c"
//
#include <stdlib.h>

/* We use the POSIX regex functions to process regular expressions.
 * Type 'man regex' for more information about POSIX regex functions.
 */
#include <sys/types.h>
#include <regex.h>

#define CHECK_SSCANF(_uint32) \
printf("CHECK_SSCANF: val = %d\n", _uint32); fflush(stdout);
#define CHECK_EVAL(p, q) \
printf("CHECK_EVAL: p = %d, q = %d\n", p, q); fflush(stdout);
#define CHECK_OP_PQ(p, q) \
printf("set_op: p = %d, q = %d\n", p, q); fflush(stdout);
#define CHECK_SETOP(op) \
printf("CHECK_SETOP: op = %d\n", op); fflush(stdout);
#define CHECK_VAL(p, q, val) \
printf("CHECK_VAL: p = %d, q = %d, val = %d\n", p, q, val); fflush(stdout);
#define CHECK_DEREF(addr, val) \
printf("CHECK_DEREF: addr = 0x%x, val = 0x%x\n", addr, val); fflush(stdout);
#define CHECK_PARENTHESES(p, q) \
printf("CHECK_PARENTHESES: p = %d, q = %d\n", p, q); fflush(stdout);
#define CHECK_PARENTHESES_IF(_booleam) \
printf("CHECK_PARENTHESES: _booleam = %d\n", _booleam); fflush(stdout);
#define CHECK_SUCCEESS \
printf("CHECK_SUCCEESS: *success = %d\n", *success);


enum
{
	NOTYPE = 256,
	EQ,
	OPR,
	NUM,
	REG,
	SYMB,
	HNUM,
	PARENTHESE,
	DEREF = 1000,
	LOGIC_OPR = 1111,
	IDENTIFIER = 6666,
	BOOLEAM = 1999
	/* TODO: Add more token types */

};

static struct rule
{
	char *regex;
	int token_type;
} rules[] = {

	/* TODO: Add more rules.
	 * Pay attention to the precedence level of different rules.
	 */
    
	{" +", NOTYPE}, // white space
	//{"\\+", '+'},
	//{"-", '-'},
	//{"\\*", '*'},
	//{"/", '/'},
	{"\\+", OPR},
	{"-", OPR},
	{"\\*", OPR},
	{"/", OPR},
	{"==", BOOLEAM},
	{"!=", BOOLEAM},
	{"&&", BOOLEAM},
	{"\\|\\|", BOOLEAM},
	{"!", LOGIC_OPR},
	//{"\\(", '('},
	//{"\\)", ')'},
	{"\\(", PARENTHESE},
	{"\\)", PARENTHESE},
	{"0x[0-9a-fA-F]+", HNUM},
	{"[0-9]+", NUM},
	{"\\$[a-z]+", REG},
	{"\\w+", IDENTIFIER},
	
	
};

#define NR_REGEX (sizeof(rules) / sizeof(rules[0]))

static regex_t re[NR_REGEX];

/* Rules are used for more times.
 * Therefore we compile them only once before any usage.
 */
void init_regex()
{
	int i;
	char error_msg[128];
	int ret;

	for (i = 0; i < NR_REGEX; i++)
	{
		ret = regcomp(&re[i], rules[i].regex, REG_EXTENDED);
		if (ret != 0)
		{
			regerror(ret, &re[i], error_msg, 128);
			assert(ret != 0);
		}
	}
}

typedef struct token
{
	int type;
	char str[32];
} Token;

Token tokens[32];

int nr_token;

#define CHECK_TOKENS(nr) \
printf("CHECK_TOKENS: tokens[%d].type = %d, tokens[%d].str = %s\n", nr, tokens[nr].type, nr, tokens[nr].str);

static bool make_token(char *e)
{
	int position = 0;
	int i;
	regmatch_t pmatch;

	nr_token = 0;

	while (e[position] != '\0')
	{
		/* Try all rules one by one. */
		for (i = 0; i < NR_REGEX; i++)
		{
			if (regexec(&re[i], e + position, 1, &pmatch, 0) == 0 && pmatch.rm_so == 0)
			{
				char *substr_start = e + position;
				int substr_len = pmatch.rm_eo;
                
				printf("match regex[%d] at position %d with len %d: %.*s\n", i, position, substr_len, substr_len, substr_start);
				position += substr_len;

				/* TODO: Now a new token is recognized with rules[i]. 
				 * Add codes to perform some actions with this token.
				 */
				 //overflow
				 if(substr_len > 32){
				     printf("expr.c: too long token at position %d\n%s\n%*.s^\n", position, e, position,"");
				     return false;
				 }
				 
				 //substr_start -> tokens[nr_token].str
				//strncpy(tokens[nr_token].str, substr_start, substr_len);
				//need to setmem before used if we use the order 'p + expression' for more than 1 time
				switch (rules[i].token_type)
				{
				case REG:
				    memset(tokens[nr_token].str, 0, sizeof(tokens[nr_token].str));
				    strncpy(tokens[nr_token].str, substr_start + 1, substr_len - 1); 
				    tokens[nr_token].type = rules[i].token_type;
					nr_token++;
				    break;
			    case HNUM:
			        memset(tokens[nr_token].str, 0, sizeof(tokens[nr_token].str));
			        strncpy(tokens[nr_token].str, substr_start + 2, substr_len - 2); 
			        tokens[nr_token].type = rules[i].token_type;
					nr_token++;
			        break;
				case NUM: 
				    memset(tokens[nr_token].str, 0, sizeof(tokens[nr_token].str));
				    strncpy(tokens[nr_token].str, substr_start, substr_len); 
				    tokens[nr_token].type = rules[i].token_type;
					nr_token++;
				    break;
				case NOTYPE://去掉空格
				    memset(tokens[nr_token].str, 0, sizeof(tokens[nr_token].str));
				    break;
				default:
				    memset(tokens[nr_token].str, 0, sizeof(tokens[nr_token].str));
				    strncpy(tokens[nr_token].str, substr_start, substr_len); 
					tokens[nr_token].type = rules[i].token_type;
					nr_token++;
				}

				break;
			}
		}

		if (i == NR_REGEX)
		{
			printf("no match at position %d\n%s\n%*.s^\n", position, e, position, "");
			return false;
		}
	}

	return true;
}

bool check_parentheses(uint32_t p, uint32_t q, bool *success, bool* deref_flag){
    
    //CHECK_PARENTHESES(p, q)
    
    // still something wrong here when input is (deref)*(addr)
    // maybe the if clause is wrong.
    
    //CHECK_PARENTHESES_IF( ( (!strcmp(tokens[p].str, "(")) || ( (tokens[p].type == DEREF && (!strcmp(tokens[p + 1].str, "("))) ) ) && (!strcmp(tokens[q].str, ")")))
    //CHECK_PARENTHESES_IF(( (tokens[p].type == DEREF && (!strcmp(tokens[p + 1].str, "("))) ))
    //CHECK_PARENTHESES_IF((!strcmp(tokens[q].str, ")")))
    
    if( ( (!strcmp(tokens[p].str, "(")) || ( (tokens[p].type == DEREF && (!strcmp(tokens[p + 1].str, "("))) ) ) && (!strcmp(tokens[q].str, ")")) ) {
    //if(((!strcmp(tokens[p].str, "(")) || (tokens[p].type == DEREF && (!strcmp(tokens[p + 1].str, "(")))) && (!strcmp(tokens[q].str, ")"))){
        int cnt_leftP = 0, cnt_rigntP = 0;
        for(int i = p; i <= q; i++){
            if((!strcmp(tokens[i].str, "("))) cnt_leftP++;
            else if((!strcmp(tokens[i].str, ")"))) cnt_rigntP++;
        }
        if(cnt_leftP == cnt_rigntP) {
            if(tokens[p].type == DEREF) { //there is a deref opr at position p
                *deref_flag = true;
            }
            else *deref_flag = false;
            return true;
        }
        else {
            *success = false;
            return false;
        }
    }
    
    return false;
}


short opr_priority_1op[200];
short opr_priority_2op[200][200];
void init_opr_priority(){
    opr_priority_1op['+'] = 5;
    opr_priority_1op['-'] = 5;
    opr_priority_1op['*'] = 10;
    opr_priority_1op['/'] = 10;
    opr_priority_1op['('] = 100;
    opr_priority_1op[')'] = 100;
    opr_priority_1op['!'] = 20;
    
    opr_priority_2op['=']['='] = 3;
    opr_priority_2op['!']['='] = 3;
    opr_priority_2op['&']['&'] = 2;
    opr_priority_2op['|']['|'] = 1;
}
bool opr_pri_L(char* a, char* b){
    int priority_a = 0, priority_b = 0;
    //printf("opr_pri_L: sizeof_a = %d, sizeof_b = %d\n", strlen(a), strlen(b)); fflush(stdout);
    //printf("opr_pri_L: a[0] = %c, b[0] = %c\n", a[0], b[0]); fflush(stdout);
    
    uint32_t len_a = strlen(a), len_b = strlen(b);
    
    switch(len_a){
        case 1:priority_a = opr_priority_1op[(int)a[0]]; break;
        case 2:priority_a = opr_priority_2op[(int)a[0]][(int)a[1]]; break;
        default:return false;
    }
    switch(len_b){
        case 1:priority_b = opr_priority_1op[(int)b[0]]; break;
        case 2:priority_b = opr_priority_2op[(int)b[0]][(int)b[1]];  break;
        default:return false;
    }
    
    //printf("opr_pri_L: priority_a = %d, priority_b = %d\n", priority_a, priority_b); fflush(stdout);
    
    return priority_a < priority_b;
}

uint32_t priL_op(uint32_t opA, uint32_t opB){
    if(opr_pri_L(tokens[opA].str, tokens[opB].str)) return opA;
    else return opB;
}

//find lowest priority op among p and q
uint32_t set_op(uint32_t p, uint32_t q, bool *success){
    //initial op
    //CHECK_OP_PQ(p, q);
    uint32_t op = -1;
    
    
    int parentheses_flag = 0;
    for(int i = p; i < q; i++){
        if(!strcmp(tokens[i].str, "(")) parentheses_flag++;
        else if(!strcmp(tokens[i].str, ")")) parentheses_flag--;
        else if((parentheses_flag <= 0) && (tokens[i].type == OPR || tokens[i].type == BOOLEAM)){
            if(op == -1) op = i;
            else op = priL_op(op, i);
            
            //printf("op changed in set_op\t"); fflush(stdout);
            //CHECK_SETOP(op);
        }
    }
    if(op < 0 || parentheses_flag != 0) { //set failure
        *success = false; return 0;
    }
    return op;
}

uint32_t deref_val(uint32_t addr){
    return vaddr_read(addr, 0, 4);
}
uint32_t neg_val(uint32_t val){
    return !val;
}

extern uint32_t look_up_symtab(char *sym, bool *success);
uint32_t tokens_val(uint32_t p, bool* success){
    uint32_t val = 0;
    
    //printf("tokens_val: p = %d\n", p);
    //CHECK_SUCCEESS
    
    switch(tokens[p].type){
        case NUM:   sscanf(tokens[p].str, "%d", &val); break;
        case HNUM:  sscanf(tokens[p].str, "%x", &val); break;
        case REG:   val = get_reg_val(tokens[p].str, success); break;
        case IDENTIFIER: val = look_up_symtab(tokens[p].str, success);break;
        default:*success = false; return 0;
    }
    
    //CHECK_SUCCEESS
    
    return val;
}

uint32_t eval(uint32_t p, uint32_t q, bool *success){
    
    //CHECK_EVAL(p, q)
    
    bool deref_flag = false;
    if(p > q) {
        /* Bad expression */
        *success = false;
        return 0;
    }
    else if(tokens[p].type == DEREF) return deref_val(eval(p + 1, q, success));
    else if(tokens[p].type == LOGIC_OPR){
        if(!strcmp(tokens[p].str, "!")) return neg_val(eval(p + 1, q, success));
        else {*success = false; return 0;}
    }
    else if(p == q) { 
        /* Single token.
         * For now this token should be a number. 
         * Return the value of the number.
         */
        uint32_t val;
        val = tokens_val(p, success);
        //CHECK_SSCANF(val)
        if(*success == false) return 0;
        return val;
    }
    else if(q - p == 1){ //maybe指针解引用
        if(tokens[p].type == DEREF){
            uint32_t addr;
            //get addr
            addr = tokens_val(q, success);
            //read addr
            //CHECK_DEREF(addr, vaddr_read(addr, 0, 4))
            return vaddr_read(addr, 0, 4);
        }
        else if(tokens[p].type == LOGIC_OPR){
            if(!strcmp(tokens[p].str, "!")) return !tokens_val(q, success);
            else {*success = false; return 0;}
        }
        else { //error: such expression is not in law
            *success = false;
            return 0;
        }
    }
    else if(check_parentheses(p, q, success, &deref_flag) == true) {
        /* The expression is surrounded by a matched pair of parentheses. 
         * If that is the case, just throw away the parentheses.
         */
         
         //printf("check_parentheses succeed!");
         
        //if deref at p : p+=2, q--; else p++, q-- (if parenthess == true)
        if(deref_flag) return deref_val(eval(p + 2, q - 1, success));
        else return eval(p + 1, q - 1, success);
    }
    else {
        //op = the position of dominant operator in the token expression;
        uint32_t op = set_op(p, q, success);
        if(*success == false)return 0;
        //CHECK_EVAL(p, q)
        //CHECK_SETOP(op)
        
        uint32_t val1 = eval(p, op - 1, success);
        
        //CHECK_VAL(p, op - 1, val1);
        
        uint32_t val2 = eval(op + 1, q, success);
        
        //CHECK_VAL(op + 1, q, val2);
        
        if(tokens[op].type == OPR){
            if(!strcmp(tokens[op].str, "+")) return val1 + val2;
            else if(!strcmp(tokens[op].str, "-")) return val1 - val2;
            else if(!strcmp(tokens[op].str, "*")) return val1 * val2;
            else if(!strcmp(tokens[op].str, "/")) return (uint32_t)(val1 / val2);//return val1 / val2;
            else {*success = false; return 0;}
        }
        else if(tokens[op].type == BOOLEAM){
            if(!strcmp(tokens[op].str, "==")) return val1 == val2;
            else if(!strcmp(tokens[op].str, "!=")) return val1 != val2;
            else if(!strcmp(tokens[op].str, "&&")) return val1 && val2;
            else if(!strcmp(tokens[op].str, "||")) return val1 || val2;
            else {*success = false; return 0;}
        }
        else {
            *success = false; return 0;
        }
        /*
        switch(tokens[op].str) {
            case '+': return val1 + val2;
            case '-': return val1 - val2;
            case '*': return val1 * val2;
            case '/': return val1 / val2;
            //default: assert(0);
            default: *success = false; return 0;
        }
        */
    }
    *success = false; return 0;
}

uint32_t expr(char *e, bool *success)
{
	if (!make_token(e))
	{
		*success = false;
		return 0;
	}
    //指针解引用识别
    /* TODO: Implement code to evaluate the expression. */
    for(int i = 0; i < nr_token; i ++) {
        //if(tokens[i].type == '*' && (i == 0 || tokens[i - 1].type == OPR || tokens[i - 1].type == PARENTHESE) ) {
        if((!strcmp(tokens[i].str, "*")) && (i == 0 || tokens[i - 1].type == OPR || (!strcmp(tokens[i - 1].str, "(")) || tokens[i - 1].type == BOOLEAM || tokens[i - 1].type == LOGIC_OPR) ) {
            tokens[i].type = DEREF;
        } 
        //CHECK_TOKENS(i)
    }
    
    init_opr_priority();
    return eval(0, nr_token - 1, success);

	//printf("\nPlease implement expr at expr.c\n");
	//fflush(stdout);
	//assert(0);

	//return 0;
}
