#include "cpu/instr.h"

make_instr_func(jmp_near)
{
        OPERAND rel;
        rel.type = OPR_IMM;
        rel.sreg = SREG_CS;
        rel.data_size = data_size;
        rel.addr = eip + 1;

        operand_read(&rel);

        int offset = sign_ext(rel.val, data_size);
        // thank Ting Xu from CS'17 for finding this bug
        print_asm_1("jmp", "", 1 + data_size / 8, &rel);

        cpu.eip += offset;

        return 1 + data_size / 8;
}

make_instr_func(jmp_short_){
    OPERAND rel;
    rel.type = OPR_IMM;
    rel.sreg = SREG_CS;
    rel.data_size = 8;
    rel.addr = eip + 1;
    
    operand_read(&rel);
    int offset = sign_ext(rel.val, 8);
    
    cpu.eip += offset;
    
    return 1 + 8 / 8;
}

make_instr_func(jmp_rmv_near){
    int len = 1;
    OPERAND rm; 
    rm.data_size = data_size;
    len += modrm_rm(eip + 1, &rm);
    
    operand_read(&rm);
    
    
    int offset = rm.val;
    if(data_size == 16) offset &= 0x0000ffff;
    cpu.eip = offset;
    
    print_asm_1("jmp", "", 1 + data_size / 8, &rm);
    
    return 0;
}

make_instr_func(jmp_via_seg){
    #ifdef IA32_SEG
    OPERAND rm;
    rm.type = OPR_IMM;
    rm.sreg = SREG_CS;
    rm.data_size = 32;
    rm.addr = eip + 1;
    operand_read(&rm);
    print_asm_1("jmp", "", 7, &rm);
    if(data_size == 16){
        rm.val &= 0x0000ffff;
    }
    //CS : EIP = ptr 16 : 16
    cpu.eip = rm.val;
    cpu.cs.val = instr_fetch(eip + 5, 2);
    //cpu.eip = 
    load_sreg(1);
    #endif
    
    return 0;
}