#include "cpu/instr.h"

#define CHECK_REGS \
printf("sar: cpu.eip = %x, cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.esp = %x\n", cpu.eip, cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.esp);

#define CHECK_CAL \
printf("sar: cpu.eip = %x, opr_src.val = %x, opr_src.addr = %x, opr_dest.val = %x, opr_dest.addr = %x\n", cpu.eip, opr_src.val, opr_src.addr, opr_dest.val, opr_dest.addr);

static void instr_execute_2op() 
{
	operand_read(&opr_src);
	operand_read(&opr_dest);
	
	//CHECK_CAL
	
	opr_dest.val = alu_sar(opr_src.val, opr_dest.val, opr_dest.data_size);
	operand_write(&opr_dest);
	
	//CHECK_CAL
	//CHECK_REGS
}

make_instr_impl_2op(sar, i, rm, b)
make_instr_impl_2op(sar, i, rm, bv)
make_instr_impl_2op(sar, c, rm, b)
make_instr_impl_2op(sar, c, rm, bv)

static void instr_execute_1op() 
{
	operand_read(&opr_src);
	opr_src.val = alu_sar(1, opr_src.val, opr_src.data_size);
	operand_write(&opr_src);
}

make_instr_impl_1op(sar, rm, b)
make_instr_impl_1op(sar, rm, v)
