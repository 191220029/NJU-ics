#include "cpu/instr.h"
/*
Put the implementations of `or' instructions here.
*/

#define CHECK_REGS \
printf("or: cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.edi = %x\n", cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.edi);
#define CHECK_CAL \
printf("or: cpu.eip = %x, opr_src.val = %x, opr_src.addr = %x, opr_dest.val = %x, opr_dest.addr = %x\n", cpu.eip, opr_src.val, opr_src.addr, opr_dest.val, opr_dest.addr);

static void instr_execute_2op(){
    operand_read(&opr_src);
    operand_read(&opr_dest);
    
    //CHECK_CAL
    
    opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
	opr_dest.val = sign_ext(opr_dest.val, opr_dest.data_size);
    
    opr_dest.val = alu_or(opr_src.val, opr_dest.val, data_size);
    
    //CHECK_CAL
    //CHECK_REGS
    
    operand_write(&opr_dest);
}

make_instr_impl_2op(or, r, rm, v)
make_instr_impl_2op(or, rm, r, b)
make_instr_impl_2op(or, i, rm, bv)
make_instr_impl_2op(or, i, rm, b)
make_instr_impl_2op(or, i, rm, v)
make_instr_impl_2op(or, rm, r, v)
make_instr_impl_2op(or, r, rm, b)
make_instr_impl_2op(or, i, a, b)
make_instr_impl_2op(or, i, a, v)
