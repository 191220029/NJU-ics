#include "cpu/instr.h"
/*
Put the implementations of `add' instructions here.
*/

#define CHECK_REGS \
printf("add: cpu.eip = %x, cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.esp = %x\n", cpu.eip, cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.esp);

#define CHECK_CAL \
printf("add: cpu.eip = %x, opr_src.val = %x, opr_src.addr = %x, opr_dest.val = %x, opr_dest.addr = %x\n", cpu.eip, opr_src.val, opr_src.addr, opr_dest.val, opr_dest.addr);

static void instr_execute_2op() 
{
    
    //CHECK_REGS
//	CHECK_CAL
    
    //OPERAND r;
    //r.addr = opr_dest.addr;
    //r.type = opr_dest.type;
    //r.data_size = 32;
    //operand_read(&r);
    
    //if(opr_dest.type == OPR_REG)
    //    opr_dest.data_size = 32;
    
    //opr_dest.data_size = 32;
	operand_read(&opr_src);
	//printf("add: r.val = %x, opr_dest.data_size = %x\n", r.val, opr_dest.data_size);
	operand_read(&opr_dest);
	
	
	//CHECK_REGS
	//CHECK_CAL
	
	opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
	opr_dest.val = sign_ext(opr_dest.val, opr_dest.data_size);
	
	//CHECK_REGS
	//CHECK_CAL
	//printf("\nadd: opr_src.val = %x, opr_src.addr = %x, opr_dest.val = %x, opr_dest.addr = %x\n", opr_src.val, opr_src.addr, opr_dest.val, opr_dest.addr);
	
	opr_dest.val = alu_add(opr_src.val, opr_dest.val, opr_dest.data_size);
	//alu_add(opr_src.val, opr_dest.val, data_size);
	
	//CHECK_REGS
	
	operand_write(&opr_dest);
	
	//CHECK_CAL
	//CHECK_REGS
}


make_instr_impl_2op(add, i, rm, v)
make_instr_impl_2op(add, i, r, v)
make_instr_impl_2op(add, r, rm, v)
make_instr_impl_2op(add, i, rm, bv)
make_instr_impl_2op(add, rm, r, v)
make_instr_impl_2op(add, rm , r, b)
make_instr_impl_2op(add, r, rm, b)
make_instr_impl_2op(add, i, a, b)
make_instr_impl_2op(add, i, rm, b)


make_instr_func(add_i2eax_v){
    OPERAND rel;
    rel.type = OPR_IMM;
    rel.sreg = SREG_CS;
    rel.data_size = data_size;
    rel.addr = eip + 1;
    
    
    operand_read(&rel);
    
    //CHECK_REGS
    
    cpu.eax = alu_add(cpu.eax, rel.val, data_size);
    
    //CHECK_REGS
    
    return 1 + data_size / 8;
}

