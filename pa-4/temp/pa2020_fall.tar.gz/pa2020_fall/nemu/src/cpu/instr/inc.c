#include "cpu/instr.h"
/*
Put the implementations of `inc' instructions here.
*/



static void instr_execute_1op() 
{
	//operand_read(&opr_dest);
	operand_read(&opr_src);
	//printf("\ninc: eip = %x, old opr_dest.val = %x\t", cpu.eip, opr_dest.val);
	//printf("\ninc: eip = %x, old opr_src.val = %x, opr_src.addr = %x, ", cpu.eip, opr_src.val, opr_src.addr);
	
	
	
	opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
	
	
	//opr_dest.val = alu_add(opr_src.val, 1, data_size);
	//opr_dest.addr = opr_src.addr;
	//opr_dest.type = OPR_MEM;
	//opr_dest.data_size = data_size;
	//operand_write(&opr_dest);
	
	//uint32_t val = opr_src.val;
	//val = alu_add(val, 1, data_size);
	//opr_src.val = val;
	//opr_src.val = 1;
	
	uint32_t cf = cpu.eflags.CF;
	
	opr_src.val = alu_add(opr_src.val, 1, opr_src.data_size);
	
	cpu.eflags.CF = cf;
	//if(opr_dest.type == OPR_MEM)
	 //   printf(", opr_dest.type == OPR_MEM, ");
	operand_write(&opr_src);
	
	//printf("new opr_dest.val = %x\t opr_dest.addr = %x\n", opr_dest.val, opr_dest.addr);
	//printf("new opr_src.val = %x, opr_src.addr = %x\n", opr_src.val, opr_src.addr);
}

make_instr_impl_1op(inc, rm, v)
make_instr_impl_1op(inc, r, v)
