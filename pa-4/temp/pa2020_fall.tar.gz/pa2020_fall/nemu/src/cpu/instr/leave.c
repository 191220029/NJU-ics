#include "cpu/instr.h"
/*
Put the implementations of `leave' instructions here.
*/

make_instr_func(leave_32){
    cpu.esp = cpu.ebp;
    
    //pop:
    
    //CHECK_REGS
    
    OPERAND r;
    r.type = OPR_MEM;
    r.addr = cpu.esp;
    r.data_size = data_size;
    r.sreg = SREG_SS;
    operand_read(&r);
    //if(data_size == 16) r.val &= 0x0000ffff;
    
    //printf("\nret: pop r.val = %x, esp = %x, eip = %x\n", r.val, cpu.esp, cpu.eip);
    //printf("ret: r.val = %x, r.addr = %x\n", r.val, r.addr);
    cpu.esp += 4;               //%esp <- %esp + 4;  
    
    //CHECK_REGS
    
    cpu.ebp = r.val;
    
    return 1;
}
