#include "cpu/instr.h"
/*
Put the implementations of `pop' instructions here.
*/

#define CHECK_EXC \
printf("pop: cpu.eip = %x, r.addr = %x, opr_src.val = %x, opr_src.addr = %x\n", cpu.eip, r.addr, opr_src.val, opr_src.addr);

#define CHECK_REGS \
printf("pop: cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.esp = %x\n", cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.esp);

static void instr_execute_1op() 
{
    //CHECK_REGS
    
    OPERAND r;
    r.type = OPR_MEM;
    r.addr = cpu.esp;         //r.addr = (%esp)
    r.data_size = data_size;
    
    operand_read(&r);
	cpu.esp += 4;               //%esp <- %esp + 4;
	
	//cpu.esp += rel.data_size / 8;
	
	opr_src.val = r.val;            //dest
	operand_write(&opr_src);
	
	//CHECK_EXC
	//CHECK_REGS
}


make_instr_impl_1op(pop, r, v)

make_instr_func(popa){
    OPERAND rel;
    rel.type = OPR_MEM;
    rel.data_size = 32;
    rel.sreg = SREG_DS;
    
    for(int i = 7; i >= 0; i--){
        if(i != 4) {
            rel.addr = cpu.esp;
            operand_read(&rel);
            cpu.gpr[i].val = rel.val;
        }
        cpu.esp += 4;
    }
    
    print_asm_0("popa", "", 1);
    return 1;
}

/*
make_instr_func(pop_rebx_v){
    OPERAND r;
    r.type = OPR_MEM;
    r.addr = cpu.ebp;
    r.data_size = data_size;
    
    operand_read(&r);
    
    return 1;
}
make_instr_func(pop_rebp_v){
     OPERAND r;
    r.type = OPR_MEM;
    r.addr = cpu.ebp;
    r.data_size = data_size;
    
    operand_read(&r);
    
    return 1;
}
*/