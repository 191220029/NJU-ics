#include "cpu/instr.h"
/*
Put the implementations of `call' instructions here.
*/

#define CHECK_REGS \
printf("call: cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x\n", cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp);


make_instr_func(call_re116_w) {
    OPERAND rel;
    rel.type = OPR_IMM;
    rel.sreg = SREG_CS;
    rel.data_size = data_size;
    rel.addr = eip + 1;
    operand_read(&rel);  
    
    //printf("\n\ncall: last eip = %x\n rel.val = %x", eip, rel.val);

    //push(%eip+len) ***:注意这里要压入的是返回后开始执行第一条指令的地址而不是call的地址
    
    OPERAND w;
    w.type = OPR_MEM;
    w.val = cpu.eip + (data_size / 8) + 1;
    w.data_size = data_size;
    if(data_size == 16) w.val &= 0x0000ffff;
	cpu.esp -= 4;               //%esp <- %esp - 4;
	w.addr = cpu.esp;
	
	//printf("\ncall: eip = %x, esp = %x, ebp = %x, w.val = eip = %x, w.addr = %x\n\n", cpu.eip, cpu.esp, cpu.ebp, w.val, w.addr);
	
	operand_write(&w);           //(%esp) <- (SOURCE)
	
    
    //printf("\n\ncall: ni eip = %x\n", eip);
    //%eip <- %eip + re132  ****:注意要加上call语句本身的长度
    return rel.val + 5;
}

make_instr_func(call_rm_v){
    int len = 1;
    OPERAND rm; 
    rm.data_size = data_size;
    len += modrm_rm(eip + 1, &rm);
    
    operand_read(&rm);
    
    
    //push(%eip+len) ***:注意这里要压入的是返回后开始执行第一条指令的地址而不是call的地址
    
    OPERAND w;
    w.type = OPR_MEM;
    w.val = cpu.eip + len;
    w.data_size = data_size;
    if(data_size == 16) w.val &= 0x0000ffff;
	cpu.esp -= data_size / 8;               //%esp <- %esp - 4;
	w.addr = cpu.esp;
	
	//printf("\ncall: eip = %x, esp = %x, ebp = %x, w.val = eip = %x, w.addr = %x\n", cpu.eip, cpu.esp, cpu.ebp, w.val, w.addr);
	
	operand_write(&w);           //(%esp) <- (SOURCE)
    
    
    int offset = rm.val;
    if(data_size == 16) offset &= 0x0000ffff;
    cpu.eip = offset;
    
    //printf("call: new eip = %x\n", cpu.eip);
    
    print_asm_1("call", "", len, &rm);
    
    return 0;
}

