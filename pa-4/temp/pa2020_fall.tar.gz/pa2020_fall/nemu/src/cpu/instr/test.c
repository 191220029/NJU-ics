#include "cpu/instr.h"
/*
Put the implementations of `test' instructions here.
*/
#define CHECK_REGS \
printf("test: cpu.eip = %x, cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x\n", cpu.eip, cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp);

static void instr_execute_2op() 
{
    
    
	operand_read(&opr_src);
	operand_read(&opr_dest);
	
	opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
	opr_dest.val = sign_ext(opr_dest.val, opr_dest.data_size);
	
	//CHECK_REGS;
	
	alu_and(opr_src.val, opr_dest.val, data_size);
	
	//CHECK_REGS
}

//uint32_t alu_and(uint32_t src, uint32_t dest, size_t data_size)

make_instr_impl_2op(test, r, rm, v)
make_instr_impl_2op(test, r, rm, b)
make_instr_impl_2op(test, i, rm, v)
make_instr_impl_2op(test, i, a, v)
make_instr_impl_2op(test, i, a, b)
make_instr_impl_2op(test, i, rm, b)