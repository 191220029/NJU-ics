#include "cpu/instr.h"
/*
Put the implementations of `lea' instructions here.
*/


static void instr_execute_2op() 
{
	//operand_read(&opr_src);
	
	
	
	opr_dest.val = opr_src.addr;
	operand_write(&opr_dest);
	
	
	//test
	//printf("lea: eip = %x, opr_src.addr = %x, opr_src.val = %x, opr_dest.val = %x\n", cpu.eip, opr_src.addr, opr_src.val,  opr_dest.val);
	//printf("cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x\n", cpu.eax, cpu.ebx, cpu.ecx, cpu.edx);
}


make_instr_impl_2op(lea, rm, r, v)

/*
make_instr_func(lea_rm2r_v){
    OPERAND rm, r;
    
    r.data_size = rm.data_size = 32;
    
    int len = 1;
    len += modrm_r_rm(eip + 1, &r, &rm);
    
    operand_read(&rm);
    r.val = rm.addr;
    operand_write(&r);
    
    //test
	printf("lea: eip = %x, opr_src.addr = %x, opr_dest.val = %x\n", cpu.eip, rm.addr, r.val);
    
    return len;
}
*/