#include "cpu/instr.h"

#define PRT_STATUS \
printf("\nmov: eip = %x, opr_src.val = %x, opr_src.addr = %x, opr_dest.addr = %x, opr_dest.val = %x\n", cpu.eip, opr_src.val, opr_src.addr, opr_dest.addr, opr_dest.val); \
printf("cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.esp = %x\n", cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.esp);

static void instr_execute_2op() 
{
	operand_read(&opr_src);
	opr_dest.val = opr_src.val;
	operand_write(&opr_dest);
	
	//test
    //PRT_STATUS
}

make_instr_impl_2op(mov, r, rm, b)
make_instr_impl_2op(mov, r, rm, v)
make_instr_impl_2op(mov, rm, r, b)
make_instr_impl_2op(mov, rm, r, v)
make_instr_impl_2op(mov, i, rm, b)
make_instr_impl_2op(mov, i, rm, v)
make_instr_impl_2op(mov, i, r, b)
make_instr_impl_2op(mov, i, r, v)
make_instr_impl_2op(mov, a, o, b)
make_instr_impl_2op(mov, a, o, v)
make_instr_impl_2op(mov, o, a, b)
make_instr_impl_2op(mov, o, a, v)


make_instr_func(mov_zrm82r_v) {
	int len = 1;
	OPERAND r, rm;
	r.data_size = data_size;
	rm.data_size = 8;
	len += modrm_r_rm(eip + 1, &r, &rm);
	
	operand_read(&rm);
	r.val = rm.val;
	operand_write(&r);

	print_asm_2("mov", "", len, &rm, &r);
	return len;
}

make_instr_func(mov_zrm162r_l) {
        int len = 1;
        OPERAND r, rm;
        r.data_size = 32;
        rm.data_size = 16;
        len += modrm_r_rm(eip + 1, &r, &rm);

        operand_read(&rm);
        r.val = rm.val;
        operand_write(&r);
	print_asm_2("mov", "", len, &rm, &r);
        return len;
}

make_instr_func(mov_srm82r_v) {
        int len = 1;
        OPERAND r, rm;
        r.data_size = data_size;
        rm.data_size = 8;
        len += modrm_r_rm(eip + 1, &r, &rm);
        
	operand_read(&rm);
        r.val = sign_ext(rm.val, 8);
        operand_write(&r);
	print_asm_2("mov", "", len, &rm, &r);
        return len;
}

make_instr_func(mov_srm162r_l) {
        int len = 1;
        OPERAND r, rm;
        r.data_size = 32;
        rm.data_size = 16;
        len += modrm_r_rm(eip + 1, &r, &rm);
        operand_read(&rm);
        r.val = sign_ext(rm.val, 16);
        operand_write(&r);

	print_asm_2("mov", "", len, &rm, &r);
        return len;
}

make_instr_func(mov_rm2s_w){
    
    int len = 1;
    opr_src.data_size = 16;
    opr_dest.data_size = 16;
    len += modrm_r_rm(eip + 1, &opr_dest, &opr_src);
    
    opr_dest.type = OPR_SREG;
    instr_execute_2op();
    
    print_asm_2("mov", "w", len, &opr_src, &opr_dest);
    load_sreg(opr_dest.addr);
    return len;
    
}

make_instr_func(mov_c2r_l) {
    int len = 1;
    opr_src.data_size = 32;
    opr_dest.data_size = 32;
    len += modrm_r_rm(eip + 1, &opr_dest, &opr_src);
    opr_src.type = OPR_CREG;
    
    instr_execute_2op();
    
    print_asm_2("mov", "l", len, &opr_src, &opr_dest);
    return len;
}

make_instr_func(mov_r2c_l) {
    int len = 1;
    opr_src.data_size = 32;
    opr_dest.data_size = 32;
    len += modrm_r_rm(eip + 1, &opr_dest, &opr_src);
    opr_dest.type = OPR_CREG;
    
    instr_execute_2op();
    
    print_asm_2("mov", "l", len, &opr_src, &opr_dest);
    return len;
}

//增加内容：
//将一个一字节的立即数存入一个寄存器
/*int mov_i2r_b(uint32_t eip, uint8_t opcode) {
    OPERAND imm, r;         //创建源操作数和目的操作数局部变量
    
    imm.type = OPR_IMM;     //配置源操作数类型
    imm.type = SREG_CS;     //设置段寄存器，PA3-2再涉及
    imm.addr = eip + 1;     //配置源操作数地址
    imm.data_size = 8;      //配置源操作数长度
    
    r.data_size = 8;        // 配置目的操作数长度
    r.type = OPR_REG;       // 配置目的操作数类型
    r.addr = opcode & 0x7;  // 配置目的操作数
    
    operand_read(&imm);   // 读源操作数的值
    r.val = imm.val;      // 将源操作数的值赋给目的操作数
    operand_write(&r);    // 写入目的操作数，完成mov动作
    
    return 2;             // 返回指令长度
}*/
