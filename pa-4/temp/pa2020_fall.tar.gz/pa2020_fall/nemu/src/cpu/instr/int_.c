#include "cpu/intr.h"
#include "cpu/instr.h"

/*
Put the implementations of `int' instructions here.

Special note for `int': please use the instruction name `int_' instead of `int'.
*/

make_instr_func(int_ib) {
    OPERAND rel;
    rel.type = OPR_IMM;
    rel.data_size = 8;
    rel.addr = eip + 1;
    rel.sreg = SREG_CS;
    operand_read(&rel);
    
    print_asm_1("int", "", 2, &rel);
    
    //GOTO TRAP-GATE-OR-INTERRUPT-GATE
    raise_sw_intr(rel.val);
    
    return 0;
}
