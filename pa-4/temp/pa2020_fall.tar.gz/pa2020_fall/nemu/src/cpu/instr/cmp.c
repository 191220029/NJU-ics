#include "cpu/instr.h"

/*
Put the implementations of `cmp' instructions here.
*/

static void instr_execute_2op() 
{
	operand_read(&opr_src);
	operand_read(&opr_dest);
	//opr_src.val = sign_ext(opr_src.val, 32);
	//opr_dest.val = sign_ext(opr_dest.val, 32);
	
	opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
	opr_dest.val = sign_ext(opr_dest.val, opr_dest.data_size);
	
	alu_sub(opr_src.val, opr_dest.val, data_size);
	
	//test 
	//printf("\ncmp: eip = %x, opr_src.val = %d, opr_dest.val = %d, opr_dest.addr = %x, opr_dest.data_size = %d\n", cpu.eip, opr_src.val, opr_dest.val, opr_dest.addr, opr_dest.data_size);
}

make_instr_impl_2op(cmp, i, rm, bv)
make_instr_impl_2op(cmp, r, rm, v)
make_instr_impl_2op(cmp, i, rm, v)
make_instr_impl_2op(cmp, rm, r, v)
make_instr_impl_2op(cmp, i, a, b)
make_instr_impl_2op(cmp, i, rm, b)
make_instr_impl_2op(cmp, rm, r, b)
make_instr_impl_2op(cmp, i, a, v)
make_instr_impl_2op(cmp, r, rm, b)
