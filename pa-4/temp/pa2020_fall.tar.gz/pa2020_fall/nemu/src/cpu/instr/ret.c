#include "cpu/instr.h"
/*
Put the implementations of `ret' instructions here.
*/

#define CHECK_REGS \
printf("ret: cpu.eip = %x, cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.esp = %x\n", cpu.eip, cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.esp);


make_instr_func(ret_near){
    //pop:
    
    //CHECK_REGS
    
    OPERAND r;
    r.type = OPR_MEM;
    r.addr = cpu.esp;
    r.data_size = data_size;
    operand_read(&r);
    //if(data_size == 16) r.val &= 0x0000ffff;
    
    //printf("\nret: pop r.val = %x, esp = %x, eip = %x\n", r.val, cpu.esp, cpu.eip);
    //printf("ret: r.val = %x, r.addr = %x\n", r.val, r.addr);
    cpu.esp += 4;               //%esp <- %esp + 4;  
    
    //CHECK_REGS
    
    int s = r.val - cpu.eip;
    //print_asm_1("ret", "", s, &r);
    
    return s;
}

make_instr_func(ret_i_wnear){
    //read imm16
    OPERAND rel;
    rel.type = OPR_IMM;
    rel.sreg = SREG_CS;
    rel.data_size = 16;
    rel.addr = eip + 1;

    operand_read(&rel);
    
    //pop:
    
    //CHECK_REGS
    
    OPERAND r;
    r.type = OPR_MEM;
    r.addr = cpu.esp;
    r.data_size = data_size;
    operand_read(&r);
    //if(data_size == 16) r.val &= 0x0000ffff;
    
    //printf("\nret: pop r.val = %x, esp = %x, eip = %x\n", r.val, cpu.esp, cpu.eip);
    //printf("ret: r.val = %x, r.addr = %x\n", r.val, r.addr);
    cpu.esp += rel.val;               //%esp <- %esp + IMM32;  
    
    //CHECK_REGS
    
    int s = r.val - cpu.eip;
    //print_asm_1("ret", "", s, &r);
    
    return s;
}

