#include "cpu/instr.h"
/*
Put the implementations of `and' instructions here.
*/

#define CHECK_REGS \
printf("and: cpu.eip = %x, cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.esp = %x\n", cpu.eip, cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.esp);

#define CHECK_CAL \
printf("and: cpu.eip = %x, opr_src.val = %x, opr_src.addr = %x, opr_dest.val = %x, opr_dest.addr = %x\n", cpu.eip, opr_src.val, opr_src.addr, opr_dest.val, opr_dest.addr);

static void instr_execute_2op() 
{
	operand_read(&opr_src);
	operand_read(&opr_dest);
	
	opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
	opr_dest.val = sign_ext(opr_dest.val, opr_dest.data_size);
	
	//CHECK_CAL
	
	opr_dest.val = alu_and(opr_src.val, opr_dest.val, data_size);
	operand_write(&opr_dest);
	
	//CHECK_CAL
	//CHECK_REGS
}


make_instr_impl_2op(and, i, rm, bv)
make_instr_impl_2op(and, rm, r, b)
make_instr_impl_2op(and, r, rm, v)
make_instr_impl_2op(and, i, rm, v)
make_instr_impl_2op(and, i, rm, b)
make_instr_impl_2op(and, i, a, b)
make_instr_impl_2op(and, i, a, v)
make_instr_impl_2op(and, rm, r, v)
make_instr_impl_2op(and, r, rm, b)
