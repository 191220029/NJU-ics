#include "cpu/instr.h"
/*
Put the implementations of `push' instructions here.
*/

#define CHECK_REGS \
printf("push: cpu.eip = %x, cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x, cpu.esp = %x\n", cpu.eip, cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp, cpu.esp);

static void instr_execute_1op() 
{
    
    //printf("\npush: old esp = %x", cpu.esp);
    
	operand_read(&opr_src);
	//cpu.esp -= opr_src.data_size / 8;
	if(opr_src.data_size == 16) cpu.esp -= 2;
	else 
	    cpu.esp -= 4;               //%esp <- %esp - 4;
    
    //push imm8指令需要对立即数进行符号扩展
    if(opr_src.type == OPR_IMM && opr_src.data_size == 8)
        opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
    //printf("\tnew esp = %x\n\n", cpu.esp);
    
    
    //printf("\neip = %x\n", cpu.eip);
    //if(opr_src.type == OPR_REG)	printf("push: SOURCE is a register!\n");
    //printf("push: SOURCE.addr = %x\tSource.data_size = %d\n", opr_src.addr, opr_src.data_size);	
	//printf("ebp = %x\n", cpu.ebp);
    //printf("push: SOURCE.val = %x\n", opr_src.val);
	opr_src.data_size = data_size;
	opr_src.type = OPR_MEM;
	opr_src.addr = cpu.esp;  
	operand_write(&opr_src);           //(%esp) <- (SOURCE)
	//printf("now ebp = %x\n", cpu.ebp);
	
	//CHECK_REGS
}

make_instr_impl_1op(push, r, v)
make_instr_impl_1op(push, rm, v)
make_instr_impl_1op(push, i, b)
make_instr_impl_1op(push, i, v)

make_instr_func(pusha){
    //uint32_t temp = cpu.esp;
    OPERAND rel;
    rel.type = OPR_MEM;
    rel.data_size = 32;
    rel.sreg = SREG_DS;
    
    for(int i = 0; i < 8; i++){
        cpu.esp -= data_size / 8;
        rel.addr = cpu.esp;
        rel.val = cpu.gpr[i].val;
        operand_write(&rel);
    }
    //cpu.esp = temp;
    
    print_asm_0("pusha", "", 1);
    
    return 1;
}

/*
make_instr_func(push_cs){
    cpu.esp -= 4;
    OPERAND rel;
    rel.addr = cpu.esp;
    rel.type = OPR_MEM;
    rel.data_size = 32;
    rel.val = sign_ext(cpu.eax, rel.data_size); //should be cs here!
    
    operand_write(&rel);
    
    return 1;
}
*/