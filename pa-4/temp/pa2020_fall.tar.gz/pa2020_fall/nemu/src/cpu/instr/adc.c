#include "cpu/instr.h"
/*
Put the implementations of `adc' instructions here.
*/

#define CHECK_REGS \
printf("adc: cpu.eax = %x, cpu.ebx = %x, cpu.ecx = %x, cpu.edx = %x, cpu.ebp = %x\n", cpu.eax, cpu.ebx, cpu.ecx, cpu.edx, cpu.ebp);

#define CHECK_CAL \
printf("adc: cpu.eip = %x, opr_src.val = %x, opr_src.addr = %x, opr_dest.val = %x, opr_dest.addr = %x\n", cpu.eip, opr_src.val, opr_src.addr, opr_dest.val, opr_dest.addr);

static void instr_execute_2op() 
{
    
    //if(opr_dest.type == OPR_REG) opr_dest.data_size = 32;
    
	operand_read(&opr_src);
	operand_read(&opr_dest);
	
	
	opr_src.val = sign_ext(opr_src.val, opr_src.data_size);
	opr_dest.val = sign_ext(opr_dest.val, opr_dest.data_size);
	
	//printf("\nadd: opr_src.val = %x, opr_src.addr = %x, opr_dest.val = %x, opr_dest.addr = %x\n", opr_src.val, opr_src.addr, opr_dest.val, opr_dest.addr);
	
	opr_dest.val = alu_adc(opr_src.val, opr_dest.val, data_size);
	
	//alu_add(opr_src.val, opr_dest.val, data_size);
	
	//CHECK_CAL
	//CHECK_REGS
	
	operand_write(&opr_dest);
}

make_instr_impl_2op(adc, r, rm, v)
make_instr_impl_2op(adc, i, rm, bv)
make_instr_impl_2op(adc, r, rm, b)
make_instr_impl_2op(adc, rm, r, b)
make_instr_impl_2op(adc, rm, r, v)
make_instr_impl_2op(adc, i, a, b)
make_instr_impl_2op(adc, i, a, v)
make_instr_impl_2op(adc, i, rm, b)
make_instr_impl_2op(adc, i, rm, v)

