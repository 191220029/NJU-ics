#include "memory/mmu/cache.h"
#include "memory/memory.h"
#include "nemu.h"
#include <stdlib.h>
#include <time.h>

#ifdef CACHE_ENABLED

#define cache_size 1024
Cache_Line cache[cache_size];

// init the cache
void init_cache()
{
	// implement me in PA 3-1
	//所有chache行的有效位置为0
	for(int i = 0; i < cache_size; i++)
	    cache[i].valid = 0;
}

// write data to cache
void cache_write(paddr_t paddr, size_t len, uint32_t data)
{
	// implement me in PA 3-1
    memcpy(hw_mem + paddr, &data, len);
    uint32_t offset = paddr & 0x3f; //64 = 2 ^ 6
	uint32_t group = (paddr >> 6) & 0x7f; //1024 = 2 ^ 10, q = 2 ^ 7, so each group has 8 lines
	uint32_t sign = (paddr >> 13) & 0x7ffff;

	
	if(offset + len > line_size){
	    cache_write(paddr, line_size - len, data);
	    cache_write(paddr + line_size - offset, len + offset - line_size, data >> (8 * (line_size - offset)));
	}
	else {
	    for(int i = 0; i < 8; i++){
    	    if(cache[i + group * 8].sign == sign && cache[i + group * 8].valid){
    	        //hit
    	        memcpy(cache[i + group * 8].block + offset, &data, len);
    	        break;
    	    }
    	}
	}
}

// read data from cache
uint32_t cache_read(paddr_t paddr, size_t len)
{
	// implement me in PA 3-1
	uint32_t ret = 0;
	uint32_t offset = paddr & 0x3f; //64 = 2 ^ 6
	uint32_t group = (paddr >> 6) & 0x7f; //1024 = 2 ^ 10, q = 2 ^ 7, so each group has 8 lines
	uint32_t sign = (paddr >> 13) & 0x7ffff;
	int i = 0;
	for(; i < 8; i++){
	    //judge if hit
	    if(cache[i + group * 8].sign == sign && cache[i + group * 8].valid){
	        //hit
	        if(offset + len <= line_size)
	            memcpy(&ret, cache[i + group * 8].block + offset, len);
	        else {
	            uint32_t r1 = 0, r2 = 0;
	            memcpy(&r1, cache[i + group * 8].block + offset, line_size - offset);
	            r2 = cache_read(paddr + line_size - offset, offset + len - line_size) << ((line_size - offset) * 8);
	            //r2 = cache_read(paddr + line_size - offset, offset + len - line_size) << ((line_size - offset));
	            ret = r1 | r2;
	        }
	        break;
	    }
	}
	if(i == 8){ //hit failed
	    memcpy(&ret, hw_mem + paddr, len);
	    for(i = 0; i < 8; i++){
	        if(cache[i + group * 8].valid == 0){
	            //chache has empty space to store
	            cache[i + group * 8].valid = 1;
	            cache[i + group * 8].sign = sign;
	            memcpy(cache[i + group * 8].block, hw_mem + paddr - offset, line_size);
	            break;
	        }
	    }
	    if(i == 8){
	        //need to remove one line to store new data
	        srand((unsigned)time(0));
	        int s = rand() % 8;
	        cache[s + group * 8].valid = 1;
	        cache[s + group * 8].sign = sign;
	        memcpy(cache[s + group * 8].block, hw_mem + paddr - offset, line_size);
	    }
	    
	}
	return ret;
}

#endif