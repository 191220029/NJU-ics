#include "cpu/cpu.h"
#include "memory/memory.h"
//#include <stdio.h>
// return the linear address from the virtual address and segment selector



uint32_t segment_translate(uint32_t offset, uint8_t sreg)
{
	/* TODO: perform segment translation from virtual address to linear address
	 * by reading the invisible part of the segment register 'sreg'
	 */
	#ifdef IA32_SEG 
    	uint32_t base = cpu.segReg[sreg].base;
    	return base + offset;
	#else 
	   return 0;
	#endif
}

// load the invisible part of a segment register
void load_sreg(uint8_t sreg)
{
	/* TODO: load the invisibile part of the segment register 'sreg' by reading the GDT.
	 * The visible part of 'sreg' should be assigned by mov or ljmp already.
	 */
	 #ifdef IA32_SEG
	 //uint32_t seg_addr = (uint32_t)hw_mem + cpu.gdtr.base + cpu.segReg[sreg].index * 8;
	 //SegDesc* segdesc = (void*)seg_addr;
	 
	 SegDesc segdesc;
	 segdesc.val[0] = laddr_read(cpu.gdtr.base + cpu.segReg[sreg].index * 8, 4);
	 segdesc.val[1] = laddr_read(cpu.gdtr.base + cpu.segReg[sreg].index * 8 + 4, 4);
	 
	 uint32_t base = (segdesc.base_31_24 << 24) + (segdesc.base_23_16 << 16) + segdesc.base_15_0;
	 uint32_t limit = (segdesc.limit_19_16 << 16) + segdesc.limit_15_0;
	 uint32_t privilege_level = segdesc.privilege_level;
	 
	 assert(base == 0);
	 assert(limit == 0xfffff);
	 assert(segdesc.present == 1);
	 assert(segdesc.granularity == 1);
	 
	 cpu.segReg[sreg].base = base;
	 cpu.segReg[sreg].limit = limit;
	 cpu.segReg[sreg].privilege_level = privilege_level;
	 #endif
}
