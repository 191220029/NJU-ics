#include "cpu/cpu.h"
#include "memory/memory.h"

// translate from linear address to physical address
paddr_t page_translate(laddr_t laddr)
{
#ifndef TLB_ENABLED
    #ifdef IA32_PAGE
	//printf("\nPlease implement page_translate()\n");
	//fflush(stdout);
	//assert(0);
	
	
	uint32_t dir = (laddr >> 22) & 0x3ff;
	uint32_t page = (laddr >> 12) & 0x3ff;
	uint32_t offset = (laddr) & 0xfff;
	PDE* page_dir = (PDE*)(hw_mem + (cpu.cr3.pdtr << 12) + (dir << 2));
	PTE* page_table = (PTE*)(hw_mem + (page_dir->page_frame << 12) + (page << 2));

    if(page_table->present == 0) fprintf(stderr,"page_translate will fail: %x\n", laddr);

	assert(page_dir->present == 1);
	assert(page_table->present == 1);
	return (page_table->page_frame << 12) + offset;
	

	
	#endif
#else
	return tlb_read(laddr) | (laddr & PAGE_MASK);
#endif
    return 0;
}
